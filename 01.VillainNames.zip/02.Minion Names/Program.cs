﻿using System;
using System.Globalization;
using Microsoft.Data.SqlClient;

namespace _02.Minion_Names
{
    class Program
    {
        static void Main(string[] args)
        {
            int villainId = int.Parse(Console.ReadLine());

            SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-B774MQCB;Initial Catalog=MinionsDB;Integrated Security=true");
            conn.Open();

            string villainidCheck = "SELECT [Name] FROM Villains WHERE Id = @villainId";

            SqlCommand cmdVillainGrab = new SqlCommand(villainidCheck, conn);
            cmdVillainGrab.Parameters.AddWithValue("villainId", villainId);

            string result = (string)cmdVillainGrab.ExecuteScalar();

            if (result == null)
            {
                Console.WriteLine($"No villain with ID {villainId} exists in the database.");
                return;
            }

            string minionsGrab =
                "SELECT m.[Name], m.Age AS Age FROM Minions AS m JOIN MinionsVillains AS mv ON m.Id = mv.MinionId WHERE mv.VillainId = @villainId";

            SqlCommand cmd = new SqlCommand(minionsGrab, conn);
            cmd.Parameters.AddWithValue("villainId", villainId);

            using (conn)
            {
                SqlDataReader reader = cmd.ExecuteReader();

                using (reader)
                {
                    Console.WriteLine($"Villain: {result}");
                    int counter = 1;

                    while (reader.Read())
                    {
                        string minionName = (string)reader["Name"];
                        int age = (int) reader["Age"];

                        Console.WriteLine($"{counter}. {minionName} {age}");
                        counter++;
                    }
                }
            }
            
        }
    }
}
