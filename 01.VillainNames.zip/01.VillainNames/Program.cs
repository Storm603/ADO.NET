﻿using System;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore.SqlServer;


namespace _01.VillainNames
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-B774MQCB;Initial Catalog=MinionsDB;Integrated Security=true");
            string query = @"SELECT [v].[Name], COUNT(mv.MinionId)  AS [Count]
		                     FROM Villains AS v 
		                     JOIN MinionsVillains AS mv ON v.Id = mv.VillainId 
		                     GROUP BY v.[Name]
		                     HAVING COUNT(mv.MinionId) > 3";

            SqlCommand cmd = new SqlCommand(query, conn);

            conn.Open();
            using (conn)
            {
                SqlDataReader reader = cmd.ExecuteReader();

                using (reader)
                {
                    while (reader.Read())
                    {
                        string name = (string)reader["Name"];
                        int minCount = (int)reader["Count"];

                        Console.WriteLine($"{name} - {minCount}");
                    }
                }
            }

            conn.Close();
        }
    }
}
