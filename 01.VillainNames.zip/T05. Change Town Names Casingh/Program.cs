﻿using System;

namespace T05._Change_Town_Names_Casingh
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
