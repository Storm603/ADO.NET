﻿using System;
using System.Linq;
using Microsoft.Data.SqlClient;

namespace T03._Add_Minion
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] minionInfo = Console.ReadLine().Split(": ", StringSplitOptions.RemoveEmptyEntries)[1]
                .Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();

            string minionName = minionInfo[0];
            int minionAge = int.Parse(minionInfo[1]);
            string townName = minionInfo[2];

            string villainName = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries)[1];
            
            SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-B774MQCB;Initial Catalog=MinionsDB;Integrated Security=true");
            conn.Open();
            
            // start of minion creation

            string minionTownCheckQuery = "SELECT Id FROM Towns WHERE [Name] = @townName";

            SqlCommand cmd = new SqlCommand(minionTownCheckQuery, conn);
            cmd.Parameters.AddWithValue("townName", townName);

            int townId = (int)cmd.ExecuteScalar();

            if (townId == 0)
            {
                SqlTransaction trans3;
                trans3 = conn.BeginTransaction();

                try
                {
                    string insertNewTownInDb = "INSERT INTO Towns([Name]) VALUES (@townName)";
                    SqlCommand insertTownWithGivenId = new SqlCommand(insertNewTownInDb, conn);
                    insertTownWithGivenId.Parameters.AddWithValue("townName", townName);

                    insertTownWithGivenId.ExecuteNonQuery();

                    Console.WriteLine($"Town {townName} was added to the database.");
                    trans3.Commit();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    trans3.Rollback();
                    throw;
                }
               
            }

            townId = (int)cmd.ExecuteScalar();

            SqlTransaction trans2;
            trans2 = conn.BeginTransaction();

            try
            {
                string insertMinionWithExistingTown = "INSERT INTO Minions VALUES (@minionName, @minionAge, @townId)";
                SqlCommand insertingMinon = new SqlCommand(insertMinionWithExistingTown, conn, trans2);
                insertingMinon.Parameters.AddWithValue("minionName", minionName);
                insertingMinon.Parameters.AddWithValue("minionAge", minionAge);
                insertingMinon.Parameters.AddWithValue("townId", townId);

                insertingMinon.ExecuteNonQuery();

                trans2.Commit();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                trans2.Rollback();
                throw;
            }
            
            // end of minion creation
            // start villain insert

            string queryCheckIfVillainExists = "SELECT [Name] FROM Villains WHERE [Name] = @villainName";
            SqlCommand checkIFVillainExists = new SqlCommand(queryCheckIfVillainExists, conn);
            checkIFVillainExists.Parameters.AddWithValue("villainName", villainName);

            string name = (string) checkIFVillainExists.ExecuteScalar();

            if (name == null)
            {
                SqlTransaction trans;
                trans = conn.BeginTransaction();

                try
                {
                    string queryInsertVillainInDb = "INSERT INTO Villains VALUES (@villainName, 4)";
                    SqlCommand villainInsert = new SqlCommand(queryInsertVillainInDb, conn, trans);
                    villainInsert.Parameters.AddWithValue("villainName", villainName);

                    villainInsert.ExecuteNonQuery();

                    trans.Commit();

                    Console.WriteLine($"Villain {villainName} was added to the database.");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    trans.Rollback();
                    return;
                }
            }

            //end villain insert
            // start inserting into mapping table

            string querygetMinionId = "SELECT Id FROM Minions WHERE [name] = @minionName";
            string querygetVillainId = "SELECT Id FROM Villains WHERE [Name] = @villainName";

            SqlTransaction trans1;
            trans1 = conn.BeginTransaction();

            try
            {
                SqlCommand insertIntoMappingTable = new SqlCommand(querygetMinionId, conn, trans1);
                insertIntoMappingTable.Parameters.AddWithValue("minionName", minionName);
                int minionId = (int)insertIntoMappingTable.ExecuteScalar();

                insertIntoMappingTable.CommandText = querygetVillainId;
                insertIntoMappingTable.Parameters.AddWithValue("villainName", villainName);
                int villainId = (int)insertIntoMappingTable.ExecuteScalar();

                string queryAddMinionToVillainMappingTable = "INSERT INTO MinionsVillains VALUES (@minionId, @villainId)";

                insertIntoMappingTable.CommandText = queryAddMinionToVillainMappingTable;
                insertIntoMappingTable.Parameters.AddWithValue("minionId", minionId);
                insertIntoMappingTable.Parameters.AddWithValue("villainId", villainId);
                insertIntoMappingTable.ExecuteNonQuery();

                trans1.Commit();

                Console.WriteLine($"Successfully added {minionName} to be minion of {villainName}");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                trans1.Rollback();
                return;
            }
        }
    }
}
